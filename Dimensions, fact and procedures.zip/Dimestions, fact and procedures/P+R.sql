CREATE PROCEDURE usp_UpsertDimReviewPayment
    @ReviewID NVARCHAR(50),
    @OrderID NVARCHAR(50),
    @ReviewScore INT,
    @PaymentType NVARCHAR(50),
    @PaymentValue DECIMAL(18,2)
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM dbo.DimReviewPayment WHERE ReviewID = @ReviewID)
    BEGIN
        -- Update existing record
        UPDATE dbo.DimReviewPayment
        SET
            OrderID = @OrderID,
            ReviewScore = @ReviewScore,
            PaymentType = @PaymentType,
            PaymentValue = @PaymentValue
        WHERE ReviewID = @ReviewID;
    END
    ELSE
    BEGIN
        -- Insert new record
        INSERT INTO dbo.DimReviewPayment (ReviewID, OrderID, ReviewScore, PaymentType, PaymentValue)
        VALUES (@ReviewID, @OrderID, @ReviewScore, @PaymentType, @PaymentValue);
    END
END;
