CREATE PROCEDURE usp_InsertDimCustomer
  @CustomerID NVARCHAR(50),
  @CustomerUniqueID NVARCHAR(50),
  @ZipCodePrefix INT,
  @City NVARCHAR(100),
  @State NVARCHAR(50)
AS
BEGIN
  SET NOCOUNT ON;

  IF NOT EXISTS (
    SELECT 1 FROM DimCustomer WHERE CustomerID = @CustomerID
  )
  BEGIN
    INSERT INTO DimCustomer (
      CustomerID, CustomerUniqueID, ZipCodePrefix, City, State
    )
    VALUES (
      @CustomerID, @CustomerUniqueID, @ZipCodePrefix, @City, @State
    )
  END
END
