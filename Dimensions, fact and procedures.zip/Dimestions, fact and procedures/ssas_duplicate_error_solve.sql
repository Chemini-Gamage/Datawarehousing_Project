UPDATE dbo.DimProduct
SET Weight_g = NULL
WHERE Weight_g = 0
AND CategoryName = 'cama_mesa_banho';

--product details--

SELECT product_weight_g, COUNT(*)
FROM dbo.DimProductDetails
WHERE product_weight_g = 0
GROUP BY product_weight_g
HAVING COUNT(*) > 1;

SELECT ProductSK,product_weight_g, product_category_name, InsertedDate, ModifiedDate
FROM dbo.DimProductDetails
WHERE product_weight_g = 0;

SELECT
    ProductSK,
    NULLIF(product_weight_g, 0) AS product_weight_g,
    product_category_name,
    InsertedDate,
    ModifiedDate
FROM dbo.DimProductDetails;

--DImReviewPayment--
SELECT
  CASE 
    WHEN ReviewCommentMessage IS NULL OR LTRIM(RTRIM(ReviewCommentMessage)) = '' THEN '<Blank>'
    ELSE ReviewCommentMessage
  END AS ReviewCommentMessage
  -- other columns
FROM dbo.DimReviewPayment



SELECT
  CASE 
    WHEN ReviewCommentMessage IS NULL OR LTRIM(RTRIM(ReviewCommentMessage)) = '' THEN NULL
    ELSE ReviewCommentMessage
  END AS ReviewCommentMessage
  -- other columns
FROM dbo.DimReviewPayment
--DimREview--

SELECT
  CASE WHEN ReviewCommentMessage = '' THEN NULL ELSE ReviewCommentMessage END AS ReviewCommentMessage
  -- other columns
FROM dbo.DimReview

SELECT 
  COALESCE(ReviewCommentMessage, '(No Comment)') AS ReviewCommentMessage
  -- other columns
FROM dbo.DimReviewPayment


SELECT
  -- other columns
  CASE WHEN ReviewCommentMessage IS NULL OR ReviewCommentMessage = '' THEN '(No Comment)' ELSE ReviewCommentMessage END AS ReviewCommentMessage
FROM dbo.DimReview



SELECT ReviewCommentMessage, COUNT(*) AS CountRows
FROM dbo.DimReview
WHERE ReviewCommentMessage = ''
GROUP BY ReviewCommentMessage
HAVING COUNT(*) > 1



UPDATE dbo.DimReview
SET ReviewCommentMessage = '<No Comment>'
WHERE ReviewCommentMessage IS NULL;


UPDATE dbo.DimReview
SET ReviewCommentMessage = '<No Comment>'
WHERE ReviewCommentMessage = '' OR ReviewCommentMessage IS NULL;


SELECT 
    COUNT(*) AS EmptyOrNullCount
FROM 
    dbo.DimReview
WHERE 
    ReviewCommentMessage IS NULL
    OR ReviewCommentMessage = ''


	SELECT 
    ReviewCommentMessage, 
    COUNT(*) AS DuplicateCount
FROM dbo.DimReview
GROUP BY ReviewCommentMessage
HAVING COUNT(*) > 1
