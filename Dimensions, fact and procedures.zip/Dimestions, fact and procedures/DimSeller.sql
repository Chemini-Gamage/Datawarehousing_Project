CREATE TABLE DimSeller (
  SellerSK INT IDENTITY PRIMARY KEY,
  SellerID NVARCHAR(50) UNIQUE,
  ZipCodePrefix INT,
  City NVARCHAR(100),
  State NVARCHAR(50)
);

