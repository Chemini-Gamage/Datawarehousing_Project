UPDATE dbo.DimProductDetails
SET InsertedDate = ISNULL(InsertedDate, GETDATE()),
    ModifiedDate = ISNULL(ModifiedDate, GETDATE()),
    EffectiveDate = ISNULL(EffectiveDate, GETDATE()),
    IsCurrent = ISNULL(IsCurrent, 1)
WHERE InsertedDate IS NULL OR ModifiedDate IS NULL OR EffectiveDate IS NULL;



CREATE PROCEDURE usp_MergeDimProduct1
  @ProductID NVARCHAR(50),
  @CategoryName NVARCHAR(100),

  @ProductNameLength INT,
  @DescriptionLength INT,
  @PhotosQty INT,
  @Weight_g INT,
  @Length_cm INT,
  @Height_cm INT,
  @Width_cm INT
AS
BEGIN
  SET NOCOUNT ON;

  MERGE DimProduct AS Target
  USING (SELECT
            @ProductID AS ProductID
        ) AS Source
  ON Target.ProductID = Source.ProductID

  WHEN MATCHED THEN
    UPDATE SET
      CategoryName = @CategoryName,
    
      ProductNameLength = @ProductNameLength,
      DescriptionLength = @DescriptionLength,
      PhotosQty = @PhotosQty,
      Weight_g = @Weight_g,
      Length_cm = @Length_cm,
      Height_cm = @Height_cm,
      Width_cm = @Width_cm

  WHEN NOT MATCHED THEN
    INSERT (
      ProductID,
      CategoryName,
   
      ProductNameLength,
      DescriptionLength,
      PhotosQty,
      Weight_g,
      Length_cm,
      Height_cm,
      Width_cm
    )
    VALUES (
      @ProductID,
      @CategoryName,

      @ProductNameLength,
      @DescriptionLength,
      @PhotosQty,
      @Weight_g,
      @Length_cm,
      @Height_cm,
      @Width_cm
    );
END;
