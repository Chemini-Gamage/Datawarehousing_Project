CREATE TABLE DimDate (
  DateKey INT PRIMARY KEY,      -- YYYYMMDD
  Date DATE,
  DayOfWeek INT,
  DayName NVARCHAR(10),
  Month INT,
  MonthName NVARCHAR(15),
  Quarter INT,
  Year INT,
  IsWeekday BIT
);

WITH dates AS (
  SELECT CAST('2015-01-01' AS DATE) AS d
  UNION ALL
  SELECT DATEADD(day, 1, d)
  FROM dates
  WHERE d < '2025-12-31'
)
INSERT INTO DimDate(DateKey, Date, DayOfWeek, DayName, Month, MonthName, Quarter, Year, IsWeekday)
SELECT CONVERT(INT, CONVERT(CHAR(8), d, 112)), d,
       DATEPART(dw, d), DATENAME(dw, d),
       DATEPART(mm, d), DATENAME(mm, d),
       DATEPART(qq, d), DATEPART(yy, d),
       CASE WHEN DATEPART(dw, d) IN (1,7) THEN 0 ELSE 1 END
FROM dates
OPTION (MAXRECURSION 0);
