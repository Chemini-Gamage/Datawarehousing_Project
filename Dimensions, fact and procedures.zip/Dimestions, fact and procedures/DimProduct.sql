CREATE TABLE DimProduct (
  ProductSK INT IDENTITY PRIMARY KEY,
  ProductID NVARCHAR(50) UNIQUE,
  CategoryName NVARCHAR(100),

  ProductNameLength INT,
  DescriptionLength INT,
  PhotosQty INT,
  Weight_g FLOAT,
  Length_cm FLOAT,
  Height_cm FLOAT,
  Width_cm FLOAT
);

