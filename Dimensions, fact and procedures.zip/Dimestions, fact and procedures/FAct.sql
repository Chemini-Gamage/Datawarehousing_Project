CREATE TABLE FactOrder (
  FactOrderSK INT IDENTITY PRIMARY KEY,
  OrderID NVARCHAR(50),
  CustomerSK INT NOT NULL,
  SellerSK INT NULL,
  ProductSK INT NULL,

  PaymentRSK INT NOT NULL,
  
  OrderStatus NVARCHAR(50),
  OrderPurchaseTimestamp DATETIME2(7),
  OrderApprovedAt DATETIME2(7),
  OrderDeliveredCarrierDate DATETIME2(7),
  OrderDeliveredCustomerDate DATETIME2(7),
  OrderEstimatedDeliveryDate DATETIME2(7),
  CarrierDateKey INT NULL,          -- FK to DimDate
  CustomerDeliveryDateKey INT NULL, -- FK to DimDate
  EstimatedDeliveryDateKey INT NULL,-- FK to DimDate
  PaymentValue FLOAT,
  PaymentInstallments TINYINT,
  ETLInsertedDate DATETIME2 DEFAULT SYSUTCDATETIME()
);
