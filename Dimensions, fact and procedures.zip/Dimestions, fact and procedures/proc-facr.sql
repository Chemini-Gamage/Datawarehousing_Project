CREATE PROCEDURE UpsertFactOrder1
    @OrderID NVARCHAR(50),
    @CustomerSK INT,
    @SellerSK INT,
    @ProductSK INT,

    @PaymentRSK INT = NULL,
    @OrderStatus INT = NULL,
    @OrderPurchaseTimestamp DATETIME = NULL,
    @OrderApprovedAt DATETIME = NULL,
    @OrderDeliveredCarrierDate DATETIME = NULL,
    @OrderDeliveredCustomerDate DATETIME = NULL,
    @OrderEstimatedDeliveryDate DATETIME = NULL,
    @CarrierDateKey INT = NULL,
    @CustomerDeliveryDateKey INT = NULL,
    @EstimatedDeliveryDateKey INT = NULL,
    @PaymentValue DECIMAL(10, 2) = NULL,
    @PaymentInstallments INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    MERGE dbo.FactOrder AS target
    USING (
        SELECT 
            @OrderID AS OrderID,
            @ProductSK AS ProductSK
    ) AS source
    ON target.OrderID = source.OrderID
       AND target.ProductSK = source.ProductSK

    WHEN MATCHED THEN
        UPDATE SET 
            CustomerSK = @CustomerSK,
            SellerSK = @SellerSK,
           
            PaymentRSK = @PaymentRSK,
            OrderStatus = @OrderStatus,
            OrderPurchaseTimestamp = @OrderPurchaseTimestamp,
            OrderApprovedAt = @OrderApprovedAt,
            OrderDeliveredCarrierDate = @OrderDeliveredCarrierDate,
            OrderDeliveredCustomerDate = @OrderDeliveredCustomerDate,
            OrderEstimatedDeliveryDate = @OrderEstimatedDeliveryDate,
            CarrierDateKey = @CarrierDateKey,
            CustomerDeliveryDateKey = @CustomerDeliveryDateKey,
            EstimatedDeliveryDateKey = @EstimatedDeliveryDateKey,
            PaymentValue = @PaymentValue,
            PaymentInstallments = @PaymentInstallments,
            ETLInsertedDate = GETDATE()

    WHEN NOT MATCHED THEN
        INSERT (
            OrderID,
            CustomerSK,
            SellerSK,
            ProductSK,
       
            PaymentRSK,
            OrderStatus,
            OrderPurchaseTimestamp,
            OrderApprovedAt,
            OrderDeliveredCarrierDate,
            OrderDeliveredCustomerDate,
            OrderEstimatedDeliveryDate,
            CarrierDateKey,
            CustomerDeliveryDateKey,
            EstimatedDeliveryDateKey,
            PaymentValue,
            PaymentInstallments,
            ETLInsertedDate
        )
        VALUES (
            @OrderID,
            @CustomerSK,
            @SellerSK,
            @ProductSK,
            
            @PaymentRSK,
            @OrderStatus,
            @OrderPurchaseTimestamp,
            @OrderApprovedAt,
            @OrderDeliveredCarrierDate,
            @OrderDeliveredCustomerDate,
            @OrderEstimatedDeliveryDate,
            @CarrierDateKey,
            @CustomerDeliveryDateKey,
            @EstimatedDeliveryDateKey,
            @PaymentValue,
            @PaymentInstallments,
            GETDATE()
        );
END;
