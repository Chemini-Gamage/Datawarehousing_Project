CREATE TABLE DimPayment (
  PaymentSK INT IDENTITY PRIMARY KEY,
  OrderID NVARCHAR(50),
  PaymentSequential TINYINT,
  PaymentType NVARCHAR(50),
  PaymentInstallments TINYINT,
  PaymentValue FLOAT
);

