WITH RankedOrders AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY OrderID
               ORDER BY OrderPurchaseTimestamp
           ) AS rn
    FROM FactOrder
)
DELETE FROM RankedOrders
WHERE rn > 1;
