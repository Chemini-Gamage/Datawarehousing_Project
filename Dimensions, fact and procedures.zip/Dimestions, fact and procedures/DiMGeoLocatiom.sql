CREATE TABLE DimGeoLocation (
  GeoLocationSK INT IDENTITY PRIMARY KEY,
  ZipPrefix INT,
  Latitude FLOAT,
  Longitude FLOAT,
  City NVARCHAR(100),
  State NVARCHAR(50)
);