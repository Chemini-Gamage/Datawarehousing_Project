CREATE TABLE DimReview (
  ReviewSK INT IDENTITY PRIMARY KEY,
  ReviewID NVARCHAR(50),
  OrderID NVARCHAR(50),
  ReviewScore INT,
  ReviewCommentTitle NVARCHAR(MAX),
  ReviewCommentMessage NVARCHAR(MAX),
  ReviewCreationDate DATETIME,
  ReviewAnswerTimestamp DATETIME
);

