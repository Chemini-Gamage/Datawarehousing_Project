IF OBJECT_ID('dbo.DimReviewPayment', 'U') IS NOT NULL
    DROP TABLE dbo.DimReviewPayment;
GO

CREATE TABLE dbo.DimReviewPayment (
    ReviewPaymentSK INT IDENTITY(1,1) PRIMARY KEY,
    
    -- Common Key
    OrderID NVARCHAR(50) NOT NULL,
    
    -- Review Columns
    ReviewID NVARCHAR(50),
    ReviewScore INT,
    ReviewCommentTitle NVARCHAR(255),
    ReviewCommentMessage NVARCHAR(MAX),
    ReviewCreationDate DATETIME,
    ReviewAnswerTimestamp DATETIME,
    
    -- Payment Columns
    PaymentSequential TINYINT,
    PaymentType NVARCHAR(50),
    PaymentInstallments TINYINT,
    PaymentValue FLOAT,

    -- Audit Columns
    CreatedDate DATETIME DEFAULT GETDATE(),
    UpdatedDate DATETIME NULL
);
