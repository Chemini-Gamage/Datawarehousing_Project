DROP TABLE DimCustomer

IF OBJECT_ID('dbo.DimCustomer', 'U') IS NOT NULL
    DROP TABLE dbo.DimCustomer;
GO

CREATE TABLE dbo.DimCustomer (
    CustomerSK INT IDENTITY(1,1) PRIMARY KEY,

    CustomerID NVARCHAR(50) NOT NULL UNIQUE,  -- Surrogate check key
    CustomerUniqueID NVARCHAR(50),
    ZipCodePrefix INT,
    City NVARCHAR(100),
    State NVARCHAR(50),
    CreatedDate DATETIME DEFAULT GETDATE(),
    ModifiedDate DATETIME NULL
);
