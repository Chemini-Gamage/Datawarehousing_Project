CREATE PROCEDURE usp_MergeDimSeller
  @SellerID NVARCHAR(50),
  @ZipCodePrefix INT,
  @City NVARCHAR(100),
  @State NVARCHAR(50)
AS
BEGIN
  SET NOCOUNT ON;

  MERGE DimSeller AS Target
  USING (SELECT @SellerID AS SellerID) AS Source
  ON Target.SellerID = Source.SellerID
  WHEN MATCHED THEN
    UPDATE SET
      ZipCodePrefix = @ZipCodePrefix,
      City = @City,
      State = @State
  WHEN NOT MATCHED THEN
    INSERT (SellerID, ZipCodePrefix, City, State)
    VALUES (@SellerID, @ZipCodePrefix, @City, @State);
END
